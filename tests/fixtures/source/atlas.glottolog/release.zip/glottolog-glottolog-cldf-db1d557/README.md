Trimmed REVA test fixture of glottolog-cldf v5.3 (Zenodo doi:10.5281/zenodo.18840967), CC BY 4.0.
