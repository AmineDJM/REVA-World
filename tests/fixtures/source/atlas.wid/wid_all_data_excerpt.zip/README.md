World Inequality Database Dataset (fixture excerpt; original README not reproduced)
