#!/bin/bash
# usage: push_batch.sh <batch_no> <file>...   (files relative to save dir)
set -euo pipefail
B=$1; shift
SAVE=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/save
R=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/pushrepo_b$B
rm -rf "$R"; mkdir -p "$R"; cd "$R"
git init -q -b reva-data-20261016-b$B
git remote add origin "$(git -C /home/user/REVA-World remote get-url origin)"
for f in "$@"; do mv "$SAVE/$f" "$R/$f"; git add "$f"; rm "$R/$f"; done
git -c user.name="Claude" -c user.email="noreply@anthropic.com" commit -qm "REVA data snapshot 2026-10-16, batch $B (see RESTORE.md in batch 1)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01MjSxEeBc788vmeDLxVaq4s"
for i in 1 2 3 4 5; do
  if git -c http.postBuffer=524288000 push -q -u origin reva-data-20261016-b$B 2>&1 | tail -3; then
    if git ls-remote origin reva-data-20261016-b$B | grep -q .; then echo "PUSHED b$B"; cd /; rm -rf "$R"; exit 0; fi
  fi
  sleep $((2**i))
done
echo "FAILED b$B (repo kept at $R)"; exit 1
