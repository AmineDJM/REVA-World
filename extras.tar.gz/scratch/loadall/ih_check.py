"""LOADALL: import a harvest DB into a THROWAWAY target DB (fidelity check before the dev DB)."""
import json, sys
from reva.adapters.connectors.wikidata import REPO_ROOT
from reva.adapters.objects.filesystem import FilesystemArtifactStore
from reva.adapters.postgres.engine import make_engine
from reva.kg import harvest as H
from reva.kg.import_harvest import import_harvest

src_db, dst_db = sys.argv[1], sys.argv[2]
src_s = H.harvest_settings(src_db)
dst_s = H.ensure_database(dst_db)
import tempfile, pathlib
root = pathlib.Path(tempfile.mkdtemp(prefix="ihcheck", dir="/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/loadall"))
rep = import_harvest(make_engine("worker", src_s), make_engine("worker", dst_s),
                     archive=FilesystemArtifactStore(H.OBJECT_ROOT, src_s.reva_s3_prefix),
                     to_store=FilesystemArtifactStore(root, dst_s.reva_s3_prefix), from_db=src_db,
                     index_path=REPO_ROOT / "var/kg/archive_index.jsonl")
print(json.dumps(rep.as_dict(), indent=1, default=str))
