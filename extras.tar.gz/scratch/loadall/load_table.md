| source | status | requests | MB | atlas tables | rows |
|---|---|---:|---:|---:|---:|
| `atlas.rcs_dem` | failed | | | | |
| `atlas.cshapes` | completed | 2 | 4.7 | 2 | 5,288 |
| `atlas.icb` | completed | 5 | 1.8 | 1 | 1,770 |
| `atlas.mid` | completed | 3 | 4.3 | 1 | 14,838 |
| `atlas.ucdp_term` | completed | 5 | 2.0 | 2 | 795 |
| `atlas.ecrises.laeven_valencia` | completed | 1 | 0.1 | 1 | 3,531 |
| `atlas.ecrises.reinhart_rogoff` | completed | 1 | 1.6 | 1 | 171,546 |
| `atlas.ecrises.jst` | completed | 2 | 1.5 | 1 | 116,882 |
| `atlas.ecrises.esrb` | completed | 1 | 0.1 | 1 | 1,785 |
| `atlas.navco` | completed | 8 | 22.2 | 3 | 104,078 |
| `atlas.mec` | completed | 2 | 1.3 | 1 | 56,144 |
| `atlas.massmob` | completed | 2 | 15.6 | 1 | 112,148 |
| `atlas.ties` | completed | 2 | 1.0 | 2 | 19,120 |
| `atlas.eusanct` | completed | 2 | 65.4 | 2 | 8,904 |
| `atlas.eu_sanctionsmap` | completed | 1 | 0.4 | 1 | 90 |
| `atlas.ofac_programs` | completed | 1 | 0.1 | 1 | 56 |
| `atlas.untc` | completed | 56 | 25.4 | 1 | 23,129 |
| `atlas.ohchr` | completed | 20 | 3.6 | 1 | 8,735 |
| `atlas.unesco_ich` | completed | 2 | 0.5 | 1 | 1,652 |
| `atlas.unesco_whc` | completed | 2 | 0.7 | 1 | 2,050 |
| `atlas.unesco_whc_links` | completed | 2 | 0.7 | 0 | 0 |
| `atlas.peacekeeping` | completed | 12 | 46.6 | 5 | 586,341 |
| `atlas.archigos` | completed | 3 | 3.4 | 1 | 26,474 |
| `atlas.noaa_hazards` | completed | 239 | 20.4 | 1 | 19,332 |
| `atlas.coldat` | completed | 5 | 0.6 | 1 | 2,526 |
| `atlas.icow` | completed | 3 | 1.1 | 2 | 3,219 |
| `atlas.cowtc` | completed | 2 | 0.8 | 2 | 5,734 |
| `atlas.cliopatria` | completed | 3 | 51.0 | 0 | 0 |
| `atlas.glottolog` | completed | 2 | 49.7 | 1 | 4,636 |
| `atlas.wals` | completed | 2 | 12.6 | 0 | 0 |
| `atlas.grambank` | completed | 2 | 9.1 | 0 | 0 |
| `atlas.openflights` | completed | 5 | 3.9 | 1 | 14,392 |
| `atlas.ourairports` | failed | | | | |
| `atlas.gcat` | completed | 5 | 34.0 | 2 | 4,530 |
| `atlas.nga_wpi` | completed | 1 | 1.3 | 1 | 548 |
| `atlas.wikidata_cables` | failed | | | | |
| `atlas.gap_cbs_bes` | completed | 4 | 0.1 | 3 | 612 |
| `atlas.gap_eurostat_nuts` | completed | 7 | 0.0 | 1 | 1,040 |
| `atlas.gap_insee` | completed | 2 | 0.1 | 2 | 1,403 |
| `atlas.gap_spc` | completed | 4 | 2.6 | 4 | 10,167 |
| `atlas.gap_jersey` | completed | 1 | 0.0 | 1 | 1,344 |
| `atlas.geonames_cities` | completed | 2 | 3.5 | 3 | 359,601 |
| `atlas.un_wup` | completed | 4 | 70.7 | 5 | 4,253,558 |
