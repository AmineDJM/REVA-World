#!/bin/bash
# split --filter: one part on stdin, name in $FILE. Adds it to the current batch repo; pushes a full batch.
set -euo pipefail
S=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/loadall/save
name=$(basename "$FILE")
B=$(cat $S/current_batch)
R=$S/repo_b$B
if [ ! -d "$R/.git" ]; then
  mkdir -p "$R"; git -C "$R" init -q -b reva-data-20261017-b$B
  git -C "$R" remote add origin "$(git -C /home/user/REVA-World remote get-url origin)"
fi
cat > "$R/$name"
( cd "$R" && sha256sum "$name" >> $S/MANIFEST.sha256 && git add "$name" && rm "$name" )
echo "$name b$B $(date -u +%T)" >> $S/parts.log
n=$(git -C "$R" diff --cached --name-only | wc -l)
if [ "$n" -ge "${PARTS_PER_BATCH:-5}" ]; then $S/push_batch.sh "$B"; echo $((B+1)) > $S/current_batch; fi
