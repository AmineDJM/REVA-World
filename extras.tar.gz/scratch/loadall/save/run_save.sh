#!/bin/bash
set -o pipefail
S=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/loadall/save
cd $S
export PARTS_PER_BATCH=5
for db in reva reva_kg_wdharvest reva_kg_causwd reva_causcand; do
  echo "$(date -u +%T) dump $db" >> parts.log
  docker exec reva-db pg_dump -U reva_owner -Fc -Z 9 $db | split -b 95M -d -a 3 --filter=$S/add_part.sh - $db.dump.part_ || { echo "FAIL dump $db" >> parts.log; exit 1; }
done
echo "$(date -u +%T) tar var/objects var/kg" >> parts.log
tar -cf - -C /home/user/REVA-World var/objects var/kg 2> $S/tar.err | split -b 95M -d -a 3 --filter=$S/add_part.sh - var_data.tar.part_
rc=$?; echo "$(date -u +%T) tar rc=$rc" >> parts.log
B=$(cat current_batch)
if [ -d repo_b$B/.git ] && [ -n "$(git -C repo_b$B diff --cached --name-only)" ]; then $S/push_batch.sh $B && echo $((B+1)) > current_batch; fi
echo "$(date -u +%T) DATA DONE" >> parts.log
