#!/bin/bash
docker exec reva-db psql -U reva_owner -d reva -Atc "select now(), unit, sum(coalesce(consumed,reserved)) from ops.budget_ledger where account_key like 'source:%' and recorded_at >= date_trunc('day', now(), 'UTC') group by 2"
