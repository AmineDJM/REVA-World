"""LOADALL: verify /v1/causal, /v1/links, /v1/atlas/headline, /v1/events on the dev DB (API test client,
temporary read token revoked afterwards). Usage: verify_causal_api.py <out.json>"""
import json
import sys
import time

from fastapi.testclient import TestClient
from pydantic import SecretStr
from sqlalchemy import text

from reva.adapters.postgres.engine import make_engine
from reva.api.app import create_app
from reva.api.auth import new_api_token
from reva.settings import Settings, get_settings

out_path = sys.argv[1]
s0 = get_settings()
settings = Settings.model_validate(
    {**s0.model_dump(), "reva_allowed_hosts": "testserver,localhost",
     "reva_session_secret": s0.reva_session_secret or SecretStr("s" * 48)}
)
owner = make_engine("migration", settings)
tok, sha = new_api_token()
with owner.begin() as c:
    tid = c.execute(
        text("INSERT INTO ops.api_token(token_sha256, scopes, label) VALUES (:h, :s, 'loadall-verify') RETURNING id"),
        {"h": sha, "s": ["read"]},
    ).scalar_one()
res = {}


def brief_claim(cl):
    keys = ("cause", "effect", "cause_id", "effect_id", "relation", "family", "stance", "grade", "source_tier",
            "source_key", "dataset", "according_to", "temporal", "corroboration", "review_status")
    return {k: cl.get(k) for k in keys if k in cl}


try:
    app = create_app(settings)
    with TestClient(app) as cl:
        H = {"Authorization": f"Bearer {tok}"}

        def get(path, **p):
            t = time.time()
            r = cl.get(path, params=p, headers=H)
            try:
                body = r.json()
            except ValueError:
                body = {"raw": r.text[:500]}
            return r.status_code, body, round(time.time() - t, 2)

        for label, eid in (("icb_cuban_missiles", "icb:crisis:196"),
                           ("laeven_valencia_ARG_2001", "ecrises:lv:systemic_banking:ARG:2001"),
                           ("laeven_valencia_USA_2007", "ecrises:lv:systemic_banking:USA:2007"),
                           ("navco_solidarity", "navco13:206-1980"),
                           ("noaa_tsunami_2011_honshu", "ncei_hazards:tsunami:5413"),
                           ("noaa_tsunami_2004_sumatra", "ncei_hazards:tsunami:2439"),
                           ("wikidata_great_depression", "Q8698")):
            st, d, t = get(f"/v1/causal/events/{eid}/why")
            res[f"why:{label}"] = {"id": eid, "status": st, "seconds": t, "body": d}
        for frm, to in (("icb:crisis:196:trigger", "icb:crisis:196:outcome"),
                        ("ncei_hazards:earthquake:9799", "ncei_hazards:tsunami:5413"),
                        ("Q201684", "Q8698")):
            st, d, t = get("/v1/causal/chain", **{"from": frm, "to": to, "max_hops": 6})
            res[f"chain:{frm}->{to}"] = {"status": st, "seconds": t, "body": d}
        st, d, t = get("/v1/causal/consistency")
        res["consistency"] = {"status": st, "seconds": t, "body": d}
        for a, b in (("USA", "GBR"), ("BRA", "PRT")):
            st, d, t = get("/v1/links/pair", a=a, b=b)
            res[f"links_pair:{a}-{b}"] = {"status": st, "seconds": t, "body": d}
        for concept, year in (("reva.population.total", 2023), ("reva.population.total_1_january", 2024),
                              ("reva.economy.gdp_usd", 2023), ("reva.health.life_expectancy_national_tables", 2022)):
            st, d, t = get("/v1/atlas/headline/map", concept=concept, year=year)
            res[f"headline_map:{concept}:{year}"] = {"status": st, "seconds": t, **({
                "with_value": d["data"]["countries_with_value"], "by_source": d["data"]["by_source"],
                "without_value": len(d["data"]["countries_without_value"])} if st == 200 else {"error": d})}
        st, d, t = get("/v1/atlas/headline/series", concept="reva.population.total", iso3="BES")
        res["headline_series:population:BES"] = {"status": st, "seconds": t, "body": d}
        st, d, t = get("/v1/events/types")
        res["events_types"] = {"status": st, "seconds": t, "n": len((d.get("data") or [])) if isinstance(d, dict) else None}
        for params in ({"from": "1962", "to": "1962", "country": "CUB", "involving": True},
                       {"from": "2011-03", "to": "2011-03", "country": "JPN"},
                       {"from": "1980", "to": "1989", "country": "POL", "involving": True}):
            st, d, t = get("/v1/events/search", **params)
            res["events_search:" + json.dumps(params, sort_keys=True)] = {"status": st, "seconds": t, "body": d}
finally:
    with owner.begin() as c:
        c.execute(text("UPDATE ops.api_token SET revoked_at = clock_timestamp() WHERE id = :i"), {"i": tid})
        res["_token_revoked"] = c.execute(text("SELECT revoked_at IS NOT NULL FROM ops.api_token WHERE id=:i"),
                                          {"i": tid}).scalar_one()
    owner.dispose()
json.dump(res, open(out_path, "w"), indent=1, default=str)
print("ok", out_path)
