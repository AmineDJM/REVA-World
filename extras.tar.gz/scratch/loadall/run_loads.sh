#!/bin/bash
# Sequential, budget-metered atlas ingests into the dev DB with a disk check before each source.
cd /home/user/REVA-World
OUT=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/loadall/loads
for src in "$@"; do
  avail=$(df --output=avail -B1 / | tail -1)
  if [ "$avail" -lt 6000000000 ]; then echo "$(date -u +%FT%TZ) STOP disk $avail bytes free before $src"; exit 4; fi
  t0=$(date +%s)
  timeout 3600 uv run reva atlas ingest "$src" > "$OUT/$src.json" 2> "$OUT/$src.err"
  rc=$?
  st=$(python3 -c "import json,sys
try:
  d=json.load(open('$OUT/$src.json')); print(d.get('status'), d.get('reason') or d.get('code') or '')
except Exception as e: print('unparsed', e)" 2>/dev/null)
  echo "$(date -u +%FT%TZ) $src rc=$rc $st $(( $(date +%s)-t0 ))s free=$(df -h --output=avail / | tail -1)"
done
echo "$(date -u +%FT%TZ) DONE"
