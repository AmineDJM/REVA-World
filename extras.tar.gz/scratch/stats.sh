#!/bin/sh
db=$1
docker exec reva-db psql -U reva_owner -d $db -c "select source_tier, count(*) from kg.causal_claim_current where origin='live' group by 1 order by 1" \
 -c "select g.rules_version, g.grade, count(*) from kg.causal_grade_current g join kg.causal_claim_current c on c.id=g.claim_row_id group by 1,2 order by 1,2" \
 -c "select g.temporal_check, count(*) from kg.causal_grade_current g join kg.causal_claim_current c on c.id=g.claim_row_id group by 1 order by 1" \
 -c "select count(*) claims, count(g.claim_row_id) graded from kg.causal_claim_current c left join kg.causal_grade_current g on g.claim_row_id=c.id"
