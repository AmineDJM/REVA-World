#!/bin/bash
# read-only psql against the dev DB
docker exec -i -e PGOPTIONS='-c default_transaction_read_only=on' reva-db psql -U reva_owner -d reva -X -P pager=off "$@"
