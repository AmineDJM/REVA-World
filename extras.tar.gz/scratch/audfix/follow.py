import json, sys, importlib.util
spec = importlib.util.spec_from_file_location("vq", sys.argv[1] + "/verify_quotes.py"); vq = importlib.util.module_from_spec(spec); spec.loader.exec_module(vq)
from pathlib import Path
path = Path(sys.argv[2]); quotes = json.loads(Path(sys.argv[3]).read_text())
lig = len(sys.argv) > 4
if path.suffix == ".docx":
    modes = {"docx": vq.paras_docx(path)}
else:
    modes = {"layout": vq.pages_pdf(path), "raw": vq.pages_pdf(path, False), "lastcol": vq.pages_lastcol(path)}
if lig:
    modes = {m: [p.replace("…", "fi").replace("¤", "ff") for p in u] for m, u in modes.items()}
out = {}
for k, q in quotes.items():
    qn = vq.norm(q)
    done = False
    for m, units in modes.items():
        r = vq.locate(units, q)
        if r["found"]:
            w = " ".join(units[r["units"][0]-1: r["units"][-1]]) if len(r["units"]) > 1 else units[r["units"][0]-1]
            i = w.find(qn)
            print(f"{k:35s} {m:8s} {r['units']}  ...{qn[-30:]!r} || NEXT: {w[i+len(qn): i+len(qn)+70]!r}")
            out[k] = {"mode": m, "units": r["units"]}
            done = True
            break
    if not done:
        print(k, "NOT FOUND")
Path(sys.argv[3].replace(".json", ".loc.json")).write_text(json.dumps(out))
