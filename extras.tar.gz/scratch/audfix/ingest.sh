#!/bin/bash
# one budget-metered atlas ingest into the dev DB under the shared lock; summary of claims deliveries
D=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/audfix/loads
cd /home/user/REVA-World
avail=$(df --output=avail -B1 / | tail -1)
if [ "$avail" -lt 5500000000 ]; then echo "STOP disk $avail"; exit 4; fi
src=$1
t0=$(date +%s)
timeout 3600 flock /tmp/reva-devdb.lock uv run reva atlas ingest "$src" > "$D/$src.json" 2> "$D/$src.err"
echo "rc=$? $(( $(date +%s)-t0 ))s free=$(df -h --output=avail / | tail -1)"
python3 - "$D/$src.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
print(d.get("status"), d.get("error"))
s = d.get("summary", {})
def rep(v):
    r = v.get("report") or v
    return {k: r.get(k) for k in ("inserted", "new", "new_revision", "unchanged", "retracted", "rejected_counts", "unknown_endpoint_claims") if k in r}
for key in ("claims", "claims_delivery", "causal"):
    v = s.get(key)
    if isinstance(v, dict) and v and all(isinstance(x, dict) for x in v.values()) and key != "causal":
        for ds, x in v.items():
            print(key, ds, x.get("status"), x.get("claims"), rep(x))
    elif isinstance(v, dict):
        print(key, v.get("status"), v.get("claims"), rep(v))
for key in ("codebooks", "codebook", "kg_retracted", "coded_links", "majres_inaction_no_claim", "claims_withheld"):
    if key in s:
        print(key, json.dumps(s[key])[:600])
kg = s.get("kg") or {}
print("kg", {k: kg.get(k) for k in ("statements_inserted", "statements_new_revision", "statements_unchanged", "retractions_inserted", "rejected")})
print("budget", d.get("budget"))
PY
