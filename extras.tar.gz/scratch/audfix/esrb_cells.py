import sys
from reva.adapters.connectors import atlas_ecrises as m
body = open(sys.argv[1], "rb").read()
b = m.parse_esrb(body, "x"*64)
seen = {}
for r in b.relations:
    seen.setdefault(r.mechanism, []).append(r.rid.rsplit(":",1)[1])
for mech, objs in seen.items():
    head = __import__("re").split(r"motivation\s*:", mech, maxsplit=1, flags=__import__("re").IGNORECASE)[0]
    print(repr(head[:200]), objs, len(mech))
