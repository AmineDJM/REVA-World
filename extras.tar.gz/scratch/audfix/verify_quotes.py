"""Check codebook quotes against archived codebook bytes (pdftotext -layout per page; docx paragraphs)."""
import json, re, subprocess, sys, zipfile, hashlib
from pathlib import Path

def norm(s):
    s = re.sub(r"-\n\s*", "-", s)  # hyphen at line end joined, hyphen kept
    return re.sub(r"\s+", " ", s).strip()

def pages_pdf(path, layout=True):
    args = ["pdftotext"] + (["-layout"] if layout else []) + [str(path), "-"]
    out = subprocess.run(args, capture_output=True, check=True).stdout.decode("utf-8")
    pages = out.split("\f")
    res = []
    for p in pages:
        lines = [l for l in p.split("\n") if not re.fullmatch(r"\s*\d{1,3}\s*", l)]  # page-number lines dropped
        res.append(norm("\n".join(lines)))
    return res

def pages_lastcol(path, min_col=30):
    out = subprocess.run(["pdftotext", "-layout", str(path), "-"], capture_output=True, check=True).stdout.decode("utf-8")
    res = []
    for p in out.split("\f"):
        keep = []
        for l in p.split("\n"):
            if re.fullmatch(r"\s*\d{1,3}\s*", l):
                continue
            m = None
            for m in re.finditer(r"\s{2,}(?=\S)", l):
                pass
            lead = len(l) - len(l.lstrip())
            if lead >= min_col:
                keep.append(l.strip())
            elif m is not None and m.end() >= min_col:
                keep.append(l[m.end():].strip())
        res.append(norm("\n".join(keep)))
    return res


def paras_docx(path):
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    paras = []
    for p in re.findall(r"<w:p[ >].*?</w:p>", xml, flags=re.S):
        t = "".join(re.findall(r"<w:t(?: [^>]*)?>(.*?)</w:t>", p, flags=re.S))
        t = t.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'")
        paras.append(norm(t))
    return paras

def locate(units, q):
    qn = norm(q)
    hits = [i + 1 for i, u in enumerate(units) if qn in u]
    if hits:
        return {"found": True, "units": hits}
    # spanning two consecutive units
    for i in range(len(units) - 1):
        if qn in units[i] + " " + units[i + 1]:
            return {"found": True, "units": [i + 1, i + 2], "spans": True}
    # longest matching prefix
    best = 0
    whole = " ".join(units)
    for n in range(len(qn), 10, -5):
        if qn[:n] in whole:
            best = n
            break
    return {"found": False, "prefix_ok": best, "at": qn[best:best + 80]}

if __name__ == "__main__":
    path = Path(sys.argv[1]); quotes = json.loads(Path(sys.argv[2]).read_text())
    modes = {"docx": paras_docx(path)} if path.suffix == ".docx" else {"layout": pages_pdf(path), "raw": pages_pdf(path, False), "lastcol": pages_lastcol(path)}
    print("sha256", hashlib.sha256(path.read_bytes()).hexdigest())
    for k, q in quotes.items():
        res = {m: locate(u, q) for m, u in modes.items()}
        ok = [m for m, r in res.items() if r["found"]]
        if ok:
            print(k, "OK", ok[0], res[ok[0]]["units"])
        else:
            m = max(res, key=lambda m: res[m]["prefix_ok"])
            r = res[m]
            whole = " ".join(modes[m]); qn = norm(q)
            i = whole.find(qn[: r["prefix_ok"]])
            print(k, "MISMATCH", m, "prefix", r["prefix_ok"], "\n   quote:", qn[r["prefix_ok"]-20: r["prefix_ok"] + 100], "\n   text :", whole[i + r["prefix_ok"] - 20: i + r["prefix_ok"] + 100])
