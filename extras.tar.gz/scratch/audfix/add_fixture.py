"""Add a captured response to tests/fixtures/source/<connector>/manifest.json (repo tool, run from the repo)."""
import hashlib, json, sys
from pathlib import Path
from reva.evidence.runner import _fixture_fingerprint
conn, url, src, ctype, licence, note = sys.argv[1:7]
d = Path("tests/fixtures/source") / conn
man = d / "manifest.json"
entries = json.loads(man.read_text()) if man.exists() else []
fp = _fixture_fingerprint(url)
body = Path(src).read_bytes()
ext = Path(src).suffix or ".bin"
name = fp[:16] + ext
(d / name).write_bytes(body)
entries = [e for e in entries if e["request_fingerprint"] != fp]
entries.append({"request_fingerprint": fp, "url": url, "file": name, "sha256": hashlib.sha256(body).hexdigest(),
                "status": 200, "headers": {"content-type": ctype}, "retrieved_at": "2026-10-16T20:18:00+00:00",
                "licence": licence, "note": note})
man.write_text(json.dumps(entries, indent=2, ensure_ascii=False) + "\n")
print(conn, name, len(body))
