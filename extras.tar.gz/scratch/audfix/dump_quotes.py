import json, sys
from pathlib import Path
out = Path(sys.argv[1])
from reva.adapters.connectors import atlas_navco as n, atlas_massmob as m, atlas_leaders as l, atlas_sanctions as s, atlas_ecrises as e
for k in ("n12", "n13", "n21", "mec"):
    (out / f"q_{k}.json").write_text(json.dumps(n.CODEBOOK[k], ensure_ascii=False))
extra = {"rep" + k: v for k, v in n.N21_REPRESSION_DEF.items()}
(out / "q_n21x.json").write_text(json.dumps(extra, ensure_ascii=False))
(out / "q_mmp.json").write_text(json.dumps(m.MANUAL, ensure_ascii=False))
(out / "q_archigos.json").write_text(json.dumps(l.CODEBOOK_DEFINITIONS, ensure_ascii=False))
(out / "q_ties.json").write_text(json.dumps(s.TIES_CODEBOOK["definitions"], ensure_ascii=False))
(out / "q_esrb.json").write_text(json.dumps({"accelerator": e.ESRB_ACCELERATOR_DEFINITION}, ensure_ascii=False))
