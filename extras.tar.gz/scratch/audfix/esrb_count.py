import sys
from collections import Counter
from reva.adapters.connectors import atlas_ecrises as m
body = open(sys.argv[1], "rb").read()
b = m.parse_esrb(body, m.sha256_hex(body))
rels = [r for r in b.relations if r.family == "causal"]
print("claims", len(rels), "truncated", sum(1 for r in rels if r.qualifiers.get("mechanism_truncated")))
print("not_a_list", len(b.report["accelerator_not_a_list"]), b.report["accelerator_not_a_list"])
print("not_coded", len(b.report["accelerator_not_coded"]))
print(Counter(r.qualifiers["objective"] for r in rels))
