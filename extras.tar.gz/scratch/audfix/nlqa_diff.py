import json, sys
sys.path.insert(0, "tests/fixtures/nlqa"); sys.path.insert(0, "tests/unit/nlqa")
import importlib.util
spec = importlib.util.spec_from_file_location("t", "tests/unit/nlqa/test_nlqa_causal.py"); t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
fresh = t._ui_answers()
old = json.loads(t.UI_FIXTURE.read_text())
def diff(a, b, path=""):
    if type(a) != type(b):
        print(path, "TYPE", str(a)[:150], "||", str(b)[:150]); return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a: print(path + "/" + k, "ADDED", str(b[k])[:200])
            elif k not in b: print(path + "/" + k, "REMOVED", str(a[k])[:200])
            else: diff(a[k], b[k], path + "/" + k)
    elif isinstance(a, list):
        if len(a) != len(b): print(path, "LEN", len(a), len(b))
        for i, (x, y) in enumerate(zip(a, b)): diff(x, y, f"{path}[{i}]")
    elif a != b:
        print(path, repr(a)[:150], "->", repr(b)[:150])
diff(old, fresh)
