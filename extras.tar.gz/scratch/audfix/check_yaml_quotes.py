import json, sys
sys.path.insert(0, sys.argv[1])
import importlib.util
spec = importlib.util.spec_from_file_location("vq", sys.argv[1] + "/verify_quotes.py"); vq = importlib.util.module_from_spec(spec); spec.loader.exec_module(vq)
import yaml
doc = yaml.safe_load(open(sys.argv[2]))
files = json.loads(sys.argv[3])
cache = {}
for ds, e in doc["datasets"].items():
    for term, d in (e.get("definitions") or {}).items():
        f = files.get(d["document"])
        if f is None:
            print("NOFILE", ds, term, d["document"]); continue
        if f not in cache:
            cache[f] = {"layout": vq.pages_pdf(f), "raw": vq.pages_pdf(f, False)}
        res = {m: vq.locate(u, d["text"]) for m, u in cache[f].items()}
        ok = [m for m, r in res.items() if r["found"]]
        pg = res[ok[0]]["units"] if ok else None
        print("OK " if ok else "BAD", ds, term, "pages", pg, "declared", d.get("pdf_page"), "" if ok else res)
