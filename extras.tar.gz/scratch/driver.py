"""WDRUN driver: run spec groups in priority order through `reva.kg.harvest run`, one process at a time,
with a watchdog that stops the run (SIGINT -> budget settled, state saved per batch) when today's ledger
usage reaches 80 % of a budget (20 % headroom for other agents) or free disk < 6 GB.

usage: python driver.py <groups.json>   groups: [{"name":..., "paths":[...], "args":[...]}]
"""
from __future__ import annotations

import json
import shutil
import signal
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

REPO = Path("/home/user/REVA-World")
LOGS = REPO / "var/kg/logs"
CAP = {"source:wikidata.wbapi:requests": 3200, "source:wikidata.wdqs:requests": 1200}
CAP_BYTES = int(0.8 * 3221225472)
MIN_FREE = 6 * 1024**3
STOPFILE = Path(__file__).resolve().parent / "STOP"


def usage() -> dict[str, int]:
    sql = ("SELECT account_key, COALESCE(sum(COALESCE(consumed,reserved)),0) FROM ops.budget_ledger "
           "WHERE recorded_at >= date_trunc('day', clock_timestamp() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC' "
           "GROUP BY 1")
    out = subprocess.run(["docker", "exec", "reva-db", "psql", "-U", "reva_owner", "-d", "reva_kg_wdharvest",
                          "-AtF", "|", "-c", sql], capture_output=True, text=True, timeout=60).stdout
    u = {}
    for line in out.strip().splitlines():
        k, v = line.split("|")
        u[k] = int(float(v))
    u["_bytes"] = sum(v for k, v in u.items() if k.endswith(":bytes"))
    return u


def over(u: dict[str, int]) -> str | None:
    for k, c in CAP.items():
        if u.get(k, 0) >= c:
            return f"{k} {u.get(k)} >= {c}"
    if u["_bytes"] >= CAP_BYTES:
        return f"bytes {u['_bytes']} >= {CAP_BYTES}"
    free = shutil.disk_usage("/").free
    if free < MIN_FREE:
        return f"disk free {free / 1e9:.1f} GB < 6 GB"
    if STOPFILE.exists():
        return "STOP file"
    return None


def log(msg: str) -> None:
    print(f"{datetime.now(UTC).isoformat(timespec='seconds')} {msg}", flush=True)


def main(groups_file: str) -> int:
    groups = json.loads(Path(groups_file).read_text())
    for g in groups:
        u = usage()
        why = over(u)
        if why:
            log(f"STOP before group {g['name']}: {why}")
            return 2
        logf = LOGS / f"wdrun_{g['name']}.log"
        cmd = ["uv", "run", "python", "-m", "reva.kg.harvest", "run", *g["paths"], *g["args"]]
        log(f"START {g['name']}: {' '.join(cmd)} usage={u}")
        with logf.open("a") as f:
            p = subprocess.Popen(cmd, cwd=REPO, stdout=f, stderr=subprocess.STDOUT)
            stopped = None
            while p.poll() is None:
                time.sleep(60)
                try:
                    why = over(usage())
                except Exception as e:  # noqa: BLE001
                    log(f"watchdog usage error {e}")
                    continue
                if why and stopped is None:
                    log(f"watchdog: {why} -> SIGINT {g['name']}")
                    p.send_signal(signal.SIGINT)
                    stopped = time.monotonic()
                elif stopped and time.monotonic() - stopped > 600:
                    log("watchdog: still running 10 min after SIGINT -> SIGTERM")
                    p.terminate()
                    stopped = time.monotonic() + 10**9
        log(f"END {g['name']}: rc={p.returncode} usage={usage()}")
        if stopped:
            return 2
    log("all groups done")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
