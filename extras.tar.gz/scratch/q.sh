#!/bin/sh
PGOPTIONS='-c default_transaction_read_only=on' psql -X -q "postgresql://reva_owner:local_reva_owner_only@127.0.0.1:5432/reva" -c "$1"
