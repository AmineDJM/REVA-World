\b(AKIA|ASIA)[0-9A-Z]{16}\b
-----BEGIN (RSA |EC |DSA |OPENSSH |ENCRYPTED |PGP )?PRIVATE KEY
\bgh[pousr]_[A-Za-z0-9]{30,}\b
\bxox[abprs]-[A-Za-z0-9-]{10,}
\bsk-(ant-|proj-)?[A-Za-z0-9_-]{24,}\b
\bAIza[0-9A-Za-z_-]{35}\b
\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}
