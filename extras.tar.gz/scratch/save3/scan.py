"""scan.py <listfile> <root>: search each file (and its gzip/bz2/zstd/zip-decompressed content) for the owner's
e-mail (env CLAUDE_CODE_USER_EMAIL), any gmail.com address and the HARD_PATTERNS of tests/security/test_secrets_logs.py."""
import bz2, gzip, io, os, re, sys, zipfile
HARD = {
    "aws_access_key_id": rb"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b",
    "private_key_block": rb"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED |PGP )?PRIVATE KEY",
    "github_token": rb"\bgh[pousr]_[A-Za-z0-9]{30,}\b",
    "slack_token": rb"\bxox[abprs]-[A-Za-z0-9-]{10,}",
    "openai_like_key": rb"\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{24,}\b",
    "google_api_key": rb"\bAIza[0-9A-Za-z_-]{35}\b",
    "jwt": rb"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}",
}
pats = {k: re.compile(v) for k, v in HARD.items()}
email = os.environ.get("CLAUDE_CODE_USER_EMAIL", "").encode().lower()
pats["gmail"] = re.compile(rb"(?i)@" rb"gmail")
try:
    import zstandard
except ImportError:
    zstandard = None

def variants(b):
    yield "raw", b
    for name, fn in (("gz", gzip.decompress), ("bz2", bz2.decompress)):
        try:
            yield name, fn(b)
        except Exception:
            pass
    if zstandard and b[:4] == b"\x28\xb5\x2f\xfd":
        try:
            yield "zst", zstandard.ZstdDecompressor().stream_reader(io.BytesIO(b)).read()
        except Exception:
            pass
    if b[:2] == b"PK":
        try:
            z = zipfile.ZipFile(io.BytesIO(b))
            for n in z.namelist():
                yield "zip:" + n, z.read(n)
        except Exception:
            pass

hits = 0
root = sys.argv[2]
for rel in open(sys.argv[1]).read().split("\n"):
    if not rel:
        continue
    b = open(os.path.join(root, rel), "rb").read()
    for how, data in variants(b):
        if email and email in data.lower():
            print(f"HIT owner-email {rel} [{how}]"); hits += 1
        for k, rx in pats.items():
            for m in rx.finditer(data):
                ctx = data[max(0, m.start() - 80): m.end() + 20].decode("utf-8", "replace").replace("\n", " ")
                print(f"HIT {k} {rel} [{how}] ...{ctx}"); hits += 1
                break
print(f"scanned; hits={hits}", file=sys.stderr)
