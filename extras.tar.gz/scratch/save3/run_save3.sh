#!/bin/bash
# run_save3.sh: stream pg_dumps and an incremental tar of var/objects+var/kg through split into batch repos.
set -o pipefail
S=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/save3
REPO=/home/user/REVA-World
cd $S
export PARTS_PER_BATCH=5
for db in reva reva_kg_causwd reva_kg_wdharvest; do
  echo "$(date -u +%T) dump $db" >> parts.log
  docker exec reva-db pg_dump -U reva_owner -Fc -Z 9 $db | split -b 95M -d -a 3 --filter=$S/add_part.sh - $db.dump.part_ || { echo "FAIL dump $db" >> parts.log; exit 1; }
done
echo "$(date -u +%T) hashing var/objects var/kg" >> parts.log
( cd $REPO && find var/objects var/kg -type f -print0 | sort -z | xargs -0 sha256sum ) > $S/FILES.sha256 || { echo "FAIL hash" >> parts.log; exit 1; }
( cd $REPO && find var/objects var/kg -type f -newerct "2026-10-17 01:10:00 UTC" | sort ) > $S/delta_files.txt
echo "$(date -u +%T) delta tar $(wc -l < delta_files.txt) files" >> parts.log
tar -cf - -C $REPO -T $S/delta_files.txt 2> $S/tar.err | split -b 95M -d -a 3 --filter=$S/add_part.sh - var_delta.tar.part_
rc=$?; echo "$(date -u +%T) tar rc=$rc" >> parts.log; [ $rc -eq 0 ] || exit 1
B=$(cat current_batch)
if [ -d repo_b$B/.git ] && [ -n "$(git -C repo_b$B diff --cached --name-only)" ]; then $S/push_batch.sh $B && echo $((B+1)) > current_batch || exit 1; fi
echo "$(date -u +%T) DATA DONE" >> parts.log
