#!/bin/bash
# split --filter: one part on stdin, name in $FILE. Adds it to the current batch repo; pushes a full batch.
# Disk guard: before writing a part, push the current batch early if free disk < 4.7 GB; wait if still low.
set -euo pipefail
S=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/save3
PFX=reva-data-20261017c-b
MINFREE=$((4700*1024*1024))
free() { echo $(( $(df -B1 --output=avail / | tail -1) )); }
name=$(basename "$FILE")
B=$(cat $S/current_batch)
R=$S/repo_b$B
if [ "$(free)" -lt $MINFREE ] && [ -d "$R/.git" ] && [ -n "$(git -C "$R" diff --cached --name-only)" ]; then
  echo "$(date -u +%T) low disk $(free) -> early push b$B" >> $S/parts.log
  $S/push_batch.sh "$B"; B=$((B+1)); echo $B > $S/current_batch; R=$S/repo_b$B
fi
for i in $(seq 1 60); do [ "$(free)" -ge $MINFREE ] && break; echo "$(date -u +%T) waiting for disk $(free)" >> $S/parts.log; sleep 30; done
[ "$(free)" -ge $MINFREE ] || { echo "$(date -u +%T) ABORT low disk" >> $S/parts.log; exit 1; }
if [ ! -d "$R/.git" ]; then
  mkdir -p "$R"; git -C "$R" init -q -b $PFX$B
  git -C "$R" remote add origin "$(git -C /home/user/REVA-World remote get-url origin)"
fi
cat > "$R/$name"
( cd "$R" && sha256sum "$name" >> $S/MANIFEST.sha256 && echo "$name $PFX$B $(stat -c %s "$name")" >> $S/PARTS.txt && git add "$name" && rm "$name" )
echo "$name b$B $(date -u +%T) free=$(free)" >> $S/parts.log
n=$(git -C "$R" diff --cached --name-only | wc -l)
if [ "$n" -ge "${PARTS_PER_BATCH:-5}" ]; then $S/push_batch.sh "$B"; echo $((B+1)) > $S/current_batch; fi
