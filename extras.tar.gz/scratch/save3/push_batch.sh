#!/bin/bash
# push_batch.sh <batch_no>: commit the staged files of repo_b<N>, push as orphan branch, verify, delete local copy.
set -uo pipefail
S=/tmp/claude-0/-home-user-REVA-World/a82f628c-2790-54df-b0b4-28930bdc7a97/scratchpad/save3
B=$1; R=$S/repo_b$B; BR=reva-data-20261017c-b$B
cd "$R" || exit 1
git rev-parse -q --verify HEAD >/dev/null || git -c user.name="Claude" -c user.email="noreply@anthropic.com" commit -qm "REVA data snapshot 2026-10-17c, batch $B (see RESTORE.md on batch 1)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01MjSxEeBc788vmeDLxVaq4s" || exit 1
H=$(git rev-parse HEAD)
for d in 0 2 4 8 16; do
  sleep $d
  git -c http.postBuffer=524288000 push -q -u origin "$BR" > $S/push_b$B.log 2>&1
  if git ls-remote origin "refs/heads/$BR" | grep -q "^$H"; then
    echo "$(date -u +%T) PUSHED $BR $(git ls-files | wc -l) files $H" >> $S/parts.log; cd /; rm -rf "$R"; exit 0
  fi
  echo "$(date -u +%T) push attempt failed $BR (next wait ${d}->x2)" >> $S/parts.log
done
echo "$(date -u +%T) FAILED $BR (kept at $R)" >> $S/parts.log; exit 1
