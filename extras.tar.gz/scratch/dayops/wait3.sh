#!/bin/bash
# bounded wait (<= $1 s) for LINKRET to commit its final work and run prune on the dev DB
cd /home/user/REVA-World
end=$(( $(date +%s) + ${1:-560} ))
while [ $(date +%s) -lt $end ]; do
  n=$(docker exec reva-db psql -U reva_owner -d reva -Atc "select count(*) from kg.link_prune" 2>/dev/null)
  if [ -n "$n" ] && [ "$n" -gt 0 ]; then echo "prune rows: $n"; break; fi
  if git log --oneline -10 | grep -v "WIP" | grep -qiE "prune|retention|LINKRET"; then echo "LINKRET final commit seen"; break; fi
  sleep 20
done
date -u; df -h --output=avail / | tail -1; git log --oneline -4 | cut -c1-160
docker exec reva-db psql -U reva_owner -d reva -Atc "select version_num from alembic_version" 2>&1 | head -2
