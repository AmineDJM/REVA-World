#!/bin/bash
# bounded wait (<= $1 s): returns when CAUSWD pid exits, a Traceback appears, or LINKRET's prune lands in git
cd /home/user/REVA-World
end=$(( $(date +%s) + ${1:-560} ))
while [ $(date +%s) -lt $end ]; do
  if ! kill -0 14826 2>/dev/null; then echo "CAUSWD exited"; break; fi
  if grep -q "Traceback" var/kg/logs/causwd_run6.log; then echo "CAUSWD traceback"; break; fi
  if git log --oneline -20 | grep -qi "prune\|retention\|LINKRET"; then echo "LINKRET commit seen"; break; fi
  sleep 15
done
date -u; df -h --output=avail / | tail -1
git log --oneline -3
grep -v UV_NATIVE var/kg/logs/causwd_run6.log | tail -2 | cut -c1-200
