#!/bin/bash
q() { docker exec reva-db psql -U reva_owner -d reva -AtF ' | ' -c "$1"; }
echo "== claims current live"; q "select count(*) from kg.causal_claim_current where origin='live'"
echo "== by tier"; q "select source_tier, count(*) from kg.causal_claim_current where origin='live' group by 1 order by 1"
echo "== by grade"; q "select g.grade, count(*) from kg.causal_claim_current c join kg.causal_grade_current g on g.claim_row_id=c.id where c.origin='live' group by 1 order by 1"
echo "== ungraded"; q "select count(*) from kg.causal_claim_current c where origin='live' and not exists (select 1 from kg.causal_grade_current g where g.claim_row_id=c.id)"
echo "== temporal"; q "select g.temporal_check, count(*) from kg.causal_claim_current c join kg.causal_grade_current g on g.claim_row_id=c.id where c.origin='live' group by 1 order by 2 desc"
echo "== by source x grade"; q "select c.source_key, count(*), count(*) filter (where g.grade='B'), count(*) filter (where g.grade='C'), count(*) filter (where g.grade='D'), count(*) filter (where g.grade='E'), count(*) filter (where g.temporal_check='inconsistent') from kg.causal_claim_current c join kg.causal_grade_current g on g.claim_row_id=c.id where c.origin='live' group by 1 order by 2 desc"
echo "== by relation"; q "select relation, count(*) from kg.causal_claim_current where origin='live' group by 1 order by 2 desc"
