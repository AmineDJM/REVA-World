#!/bin/bash
# bounded wait (<= $1 s) for LINKRET's prune command to be committed
cd /home/user/REVA-World
end=$(( $(date +%s) + ${1:-560} ))
while [ $(date +%s) -lt $end ]; do
  if git log --oneline -20 | grep -qiE "prune|retention|LINKRET"; then echo "LINKRET commit seen"; break; fi
  sleep 20
done
date -u; df -h --output=avail / | tail -1; git log --oneline -3 | cut -c1-150; git status --short | head -15
ps aux | grep -E "causal_harvest|links|pytest" | grep -v grep | awk '{print $2, substr($0, index($0,$11), 160)}' | head -5
